var sampleData = ({
    'lameCows': 10,
    'emptyCows' : 5,
    'feedCost' : 257
});